﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicioMotor
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double[] motor = new double[15];
            double total;
            int escolha;
            int a = 1;
            int p = 0;
         
            do
            {
                Console.Clear();

                Console.WriteLine("Digite 0 para sair.");
                Console.WriteLine("Digite 1 para Lançar Valor de algum motor.");
                Console.WriteLine("Digite 2 para Mostra Valor.");

                Console.WriteLine("\nQual a sua opção?");
                escolha = int.Parse(Console.ReadLine());

                while (escolha < 0 || escolha > 2)
                {
                    Console.WriteLine("Escolha uma opção entre as declaradas no menu ");
                    escolha = int.Parse(Console.ReadLine());
                }
                Console.Clear();

                if (escolha == 1)
                {
                    Console.WriteLine("Escolha um motor de 1 a 15");
                    p = int.Parse(Console.ReadLine());

                    while (p < 1 || p > 15)
                    {
                        Console.WriteLine("Escolha um motor de 1 a 15");
                        p = int.Parse(Console.ReadLine());
                    }

                    Console.WriteLine("Escolha um valor para o motor {0}: ", p);
                    motor[--p] = double.Parse(Console.ReadLine());

                    Console.WriteLine("Aperte qualquer tecla para apresentar o menu ");
                    Console.ReadKey();
                }

                if (escolha == 2)
                {

                    for (int x = 0; x < 15; x++)
                    {
                        Console.WriteLine("Motor:{0: 00} foi declarado com o valor: {1}", a, motor[x]);
                        a++;
                    }

                    a = 1;

                    total = motor[0] + motor[1] + motor[2] + motor[3] + motor[4] + motor[5] + motor[6] + motor[7] + motor[8] + motor[9] + motor[10] + motor[11] + motor[12] + motor[13] + motor[14];


                    Console.WriteLine("Valor total de todos os motores: {0}", total);
                    Console.WriteLine("Aperte qualquer tecla para apresentar o menu ");
                    Console.ReadKey();
                }

            } while (escolha != 0);

        }
    }
}
